const posts = [
    {
        title: "First post",
        body: " This is my first post"
    }
]

export default posts;